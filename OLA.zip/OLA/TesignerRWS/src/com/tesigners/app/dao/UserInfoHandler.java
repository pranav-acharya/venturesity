package com.tesigners.app.dao;

import java.sql.Connection;

import javax.ws.rs.core.Response;

public class UserInfoHandler {

	public Response fetchUserDetail(Connection connection, int id) {
		return null;
	}

}
