Main files:

1.OLARide.html
2.MerchantDashBoard.html (TesignerRWS project is a REST Web service which act provides services to the merchant)



